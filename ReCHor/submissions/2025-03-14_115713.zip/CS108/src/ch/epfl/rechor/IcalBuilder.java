package ch.epfl.rechor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Objects;
import java.util.StringJoiner;

/**
 * @author Matteo Lazzari (397247)
 * @author Pamphil Nedev (380400)
 * builder class, used to construct events in an Icalendar format,
 *      that can then be exported as a .ics file
 */

public final class IcalBuilder {
    private final ArrayList<Component> components = new ArrayList<>();
    private final StringBuilder stringBuilder = new StringBuilder();
    private final static int LINE_SIZE = 75;
    private final static String CRLF = "\r\n";

    /**
     * enum used to keep track of the opened Components
     */
    public enum Component {
        VCALENDAR,
        VEVENT;
    }

    /**
     * enum used to centralize all the possible names (at least for the ReCHor project)
     *      that can be used inside an Icalendar file
     */
    public enum Name {
        BEGIN,
        END,
        PRODID,
        VERSION,
        UID,
        DTSTAMP,
        DTSTART,
        DTEND,
        SUMMARY,
        DESCRIPTION;
    }

    /**
     *
     * @param name the left String displayed before the ":" in a .ics file
     * @param value the value associated to the name parameter in a .ics file
     * @return the current instantiation of IcalBuilder
     */

    /*

    public IcalBuilder add (Name name, String value) {


        int currentLineSize = name.toString().length() + 1;
        stringBuilder.append(name).append(":");
        for (int i = 0; i < value.length(); i++) {
            if (currentLineSize < 75) {
                stringBuilder.append(value.charAt(i));
                currentLineSize++;
            } else {
                stringBuilder.append("\r\n ");
                stringBuilder.append(value.charAt(i));
                currentLineSize = 2;
            }
        }
        stringBuilder.append("\r\n");
        return this;
    }

     */




    public IcalBuilder add (Name name, String value) {

        String text = name.toString().concat(":").concat(value);
        StringJoiner sj = new StringJoiner(CRLF + " ");

        double numberOfReturns = Math.floor((double) (text.length()) / LINE_SIZE);
        int includedStartIdx = 0;
        for (int i = 0; i <= numberOfReturns; i++) {
           int length = (i == 0) ? LINE_SIZE : LINE_SIZE -1;
           int endExcludedIdx = Math.min(includedStartIdx + length, text.length());
           sj.add(text.substring(includedStartIdx,endExcludedIdx));
           includedStartIdx = endExcludedIdx;
        }
        stringBuilder.append(sj).append(CRLF);
        return this;
    }




    /**
     * private method used to format a date for the .ics file
     * @param date the date that needs to be instantiated
     * @return the current instantiation of IcalBuilder
     */

    private String icsFormatDate (LocalDateTime date) {
        DateTimeFormatter fmt = new DateTimeFormatterBuilder()
                .appendValue(ChronoField.YEAR)
                .appendValue(ChronoField.MONTH_OF_YEAR,2)
                .appendValue(ChronoField.DAY_OF_MONTH,2)
                .appendLiteral("T")
                .appendValue(ChronoField.HOUR_OF_DAY,2)
                .appendValue(ChronoField.MINUTE_OF_HOUR,2)
                .appendValue(ChronoField.SECOND_OF_MINUTE,2)
                .toFormatter();
        return date.format(fmt);

    }

    /**
     *
     * @param name the name of the line added
     * @param dateTime a date that needs to be added in the correct .ics format
     * @return the current instantiation of IcalBuilder
     */

    public IcalBuilder add (Name name, LocalDateTime dateTime) {
        stringBuilder.append(name)
                .append(":")
                .append(icsFormatDate(dateTime))
                .append(CRLF);

        return this;

    }

    /**
     * method used to create a line in a .ics file
     *      with the name "BEGIN" and the given component
     * @param component
     * @return the current instantiation of IcalBuilder
     */

    public IcalBuilder begin (Component component) {
        stringBuilder.append(Name.BEGIN)
                .append(":")
                .append(component)
                .append(CRLF);


        components.add(component);
        return this;

    }

    /**
     * method used to close a component in a .ics file
     *      using the "END" name.
     * @return the current instantiation of IcalBuilder
     */

    public IcalBuilder end() {
        Preconditions.checkArgument(!components.isEmpty());
        Component lastComponentStarted = components.getLast();
        components.removeLast();
        stringBuilder.append(Name.END)
                .append(":")
                .append(lastComponentStarted)
                .append(CRLF);

        return this;

    }

    /**i
     * method used to transform the object IcalBuilder
     *      into a string, once the .ics file is finished
     * @throws IllegalArgumentException if a component has not been ended
     * @return the string associated to the stringbuilder IcalBuilder
     */
    public String build() {
        Preconditions.checkArgument(components.isEmpty());
        return stringBuilder.toString();

    }


}
